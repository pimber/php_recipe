<?php

namespace Vich\UploaderBundle\Mapping;

interface AnnotationInterface
{
}
