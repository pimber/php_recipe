<?php

namespace Vich\UploaderBundle\Exception;

final class NotUploadableException extends \InvalidArgumentException implements VichUploaderExceptionInterface
{
}
